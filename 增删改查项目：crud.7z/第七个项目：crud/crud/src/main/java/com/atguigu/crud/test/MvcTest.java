package com.atguigu.crud.test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import com.atguigu.crud.bean.Employee;
import com.github.pagehelper.PageInfo;

/**
 * 使用spring提供的测试模拟请求功能，测试crud请求功能
 * 注意：在servlet3.0测试时会报错java/sevlet/SessionCookieConfig
 * ；改用spring4测试的时候需要servlet3.0的支持即可，
 * 类名称：MvcTest  
 * 类描述：
 * 创建人：邱南亚 
 * 修改人：邱南亚 
 * 修改时间：2018-11-26 上午10:52:16 
 * 修改备注： 
 * @version 1.0.0
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations={"classpath:spring/applicationContext.xml","file:src/main/resources/spring/springmvc.xml"})
public class MvcTest {
    //传入springmvc的ioc
	@Autowired
	WebApplicationContext context;
	MockMvc mockMvc;
	@Before
	public void initMockMvc(){
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}
	
	@Test
	public void testPage() throws Exception{
		//单元测试；模拟请求，拿到返回值
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/emps").param("pn","4")).andReturn();
		
		//请求成功后，请求域中会有PageInfo进行校验
		MockHttpServletRequest request=result.getRequest();
		PageInfo pi = (PageInfo) request.getAttribute("PageInfo");
		System.err.println("当前页码："+pi.getPageNum());
		System.err.println("总页码（共多少页）："+pi.getPages());
		System.err.println("总记录数："+pi.getTotal());
		System.err.println("在页面需要连续显示的页码：");
		int [] nums=pi.getNavigatepageNums();
		
		for (int i : nums) {
			System.out.print(" "+i);
		}
		
		//获取员工数据
		List<Employee> list = pi.getList();
		for (Employee employee : list) {
			System.out.println("ID:"+employee.getId()+"===>name:"+employee.getEmpName());
		}
		
	}
	
}
