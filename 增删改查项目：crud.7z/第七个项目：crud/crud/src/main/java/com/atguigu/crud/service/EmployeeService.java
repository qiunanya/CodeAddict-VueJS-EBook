package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.atguigu.crud.bean.DepartmentExample.Criteria;
import com.atguigu.crud.bean.Employee;
import com.atguigu.crud.bean.EmployeeExample;
import com.atguigu.crud.dao.EmployeeMapper;

@Service
public class EmployeeService {

	@Autowired
	EmployeeMapper employeeMapper;
	
	/**
	 * 查询所有员工
	 * 作者:邱南亚 
	 * 方法名：getAllEmployees  
	 * @return   
	 * 返回值类型：List<Employee>  
	 * @exception   
	 * @since  1.0.0
	 * 2018-11-26上午10:14:29
	 */
	public List<Employee> getAllEmployees() {
		List<Employee> employees = employeeMapper.selectByExampleWithDept(null);
		//System.out.println("~~~~~~~"+employees);
		return employees;
	}
	
	
   /**
    * 员工保存
    * 作者:邱南亚 
    * 方法名：saveEmployee  
    * @param employee   
    * 返回值类型：void  
    * @exception   
    * @since  1.0.0
    * 2018-12-16下午3:38:03
    */
	public void saveEmployee(Employee employee) {
		employeeMapper.insertSelective(employee);
		
	}


	/**
	 * 校验员工姓名是否存在
	 * 作者:邱南亚 
	 * 方法名：checkUserName 
	 * @return true:代表当前姓名可用
	 * 2018-12-16下午9:25:58
	 */
public boolean checkUserName(String empName) {
	EmployeeExample example=new EmployeeExample();
	com.atguigu.crud.bean.EmployeeExample.Criteria createCriteria = example.createCriteria();
	createCriteria.andEmpNameEqualTo(empName);
	long count = employeeMapper.countByExample(example);
	
	return count==0;
}

/**
 * 根据id查询员工信息
 */
	public Employee getEmp(Integer id) {
		Employee employee = employeeMapper.selectByPrimaryKey(id);
		return employee;
	}

/**
 * 更新员工，有选择的更新
 * 作者:邱南亚 
 * 方法名：updateEmpByIds  
 * @param employee   
 * 返回值类型：void  
 * @exception   
 * @since  1.0.0
 * 2018-12-17下午11:34:47
 */
public void updateEmpByIds(Employee employee) {
	employeeMapper.updateByPrimaryKeySelective(employee);
	
}


public void deleteEmpById(Integer id) {
	employeeMapper.deleteByPrimaryKey(id);
	
}


public void deleteBacth(List<Integer> ids) {
	EmployeeExample example=new EmployeeExample();
	com.atguigu.crud.bean.EmployeeExample.Criteria createCriteria = example.createCriteria();
	//delete form xxx where id in (1,2,3)
	createCriteria.andIdIn(ids);
	employeeMapper.deleteByExample(example);
	
}

	
}
