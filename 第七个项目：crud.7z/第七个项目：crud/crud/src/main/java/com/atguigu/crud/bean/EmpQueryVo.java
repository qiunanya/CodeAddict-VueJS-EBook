package com.atguigu.crud.bean;
//查询条件
public class EmpQueryVo {

	private String emp_name;

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
     
	
	
	
}
