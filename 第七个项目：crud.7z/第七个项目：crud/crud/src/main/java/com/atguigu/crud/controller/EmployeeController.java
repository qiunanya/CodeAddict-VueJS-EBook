package com.atguigu.crud.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.atguigu.crud.bean.EmpQueryVo;
import com.atguigu.crud.bean.Employee;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.service.EmployeeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
public class EmployeeController {
   @Autowired
   EmployeeService employeeService;
   
   /**
    * 校验用户名是否可用：
    */
   @RequestMapping("/checkusername")
   @ResponseBody
   public Msg checkUserName(@RequestParam("empName")String empName){
	   //检查用户名是否规范
	   String regex="(^[a-zA-Z0-9_-]{6,16}$)|(^[\u2E80-\u9FFF]{2,5})";
	   if (!empName.matches(regex)) {
		   return Msg.failed().add("va_msg", "用户名可以是2-5位中文或者6-16英文和数字的组合");
	   }
	   System.out.println("员工姓名是："+empName);
	   boolean b=employeeService.checkUserName(empName);
	   if (b) {
		return Msg.success();
	}else {
		return Msg.failed().add("va_msg", "用户名不可用");
	}
	  
   }
   
   
   /**
    * 员工保存
    * 作者:邱南亚 
    * 方法名：saveEmployee  
    * @return   
    * 返回值类型：Msg  
    * @exception   
    * @since  1.0.0
    * 2018-12-16下午3:36:07
    */
   @RequestMapping(value="/emp",method=RequestMethod.POST)
   @ResponseBody
   public Msg saveEmployee(Employee employee){
	   
	   employeeService.saveEmployee(employee);
	   return Msg.success();
   }
   
   
   /**
    * 查询员工信息
    * 作者:邱南亚 
    * 方法名：getEmpsWithJson 
    * @return   
    * 返回值类型：Msg  
    * @exception   
    * @since  1.0.0
    * 2018-12-17下午10:38:18
    */
   @RequestMapping(value="/emp/{id}",method=RequestMethod.GET)
   @ResponseBody
   public Msg getEmps(@PathVariable("id")Integer id){
	  Employee employee= employeeService.getEmp(id);
	  
	   return Msg.success().add("emp", employee);
   }
   
   /**
    * 更新员工
    * 作者:邱南亚 
    * 方法名：getEmpsWithJson 
    * 2018-12-17下午11:29:34
    */
   @RequestMapping(value="/emp/{id}",method=RequestMethod.PUT)
   @ResponseBody
   public Msg updateEmpById(Employee employee){
	   employeeService.updateEmpByIds(employee);
	   return Msg.success();
   }
   
   //根据id删除员工信息
//   @RequestMapping(value="/emp/{id}",method=RequestMethod.DELETE)
//   @ResponseBody
//   public Msg deleteEmployeeById(@PathVariable("id")Integer id){
//	   employeeService.deleteEmpById(id);
//	   
//	   return Msg.success();
//   }
   
   /**
    * 单个批量删除二合一
    * 作者:邱南亚 
    * 方法名：deleteEmployeeById  
    * @param id
    * @return   
    * 返回值类型：Msg  
    * 2018-12-20上午9:38:12
    */
   @RequestMapping(value="/emp/{ids}",method=RequestMethod.DELETE)
   @ResponseBody
   public Msg deleteEmployeeById(@PathVariable("ids")String ids){
	   
	   if (ids.contains("-")) {
		//批量删除
		List<Integer> dele_ids=new ArrayList<Integer>();
		System.out.println("批量删除的id是："+ids);
		String[] str_ids = ids.split("-");
		for (String string : str_ids) {
			dele_ids.add(Integer.parseInt(string));
		}
		employeeService.deleteBacth(dele_ids);
	   } else {
		//2.单个删除
        Integer id=Integer.parseInt(ids);
        System.out.println("单个删除的id是："+id);
        employeeService.deleteEmpById(id);
	}
	  
	   
	   return Msg.success();
   }
   
   
   //返回json，实现客户端的无关性；
   @RequestMapping("/emps")
   @ResponseBody
   public Msg getEmpsWithJson(@RequestParam(value="pn",defaultValue="1")Integer pn,String empName,Model model,
		   HttpServletRequest request,HttpServletResponse response){
	 //引入PageHelper分页插件
	 		//在查询之前需要传入页码，每页大小
	 		//startPage后面紧跟的这个查询就是一个分页查询
	 		PageHelper.startPage(pn,10);
	 		List<Employee> emps=employeeService.getAllEmployees();
	 		System.out.println("----------"+emps);
	 		//使用PageInfo包装查询结果，只需要将PageInfo交给页面
	 		//封装详细的分页信息，包括有我们查询出来的数据,连续显示5页
	 		PageInfo<Employee> page = new PageInfo<Employee>(emps,5);
	 		System.out.println("-------------"+page);
	   
	 		return Msg.success().add("pageInfo", page);
   }
   
 //返回json，实现客户端的无关性；
   @RequestMapping("/emps_search")
   @ResponseBody
   public Msg getEmpsWithJsonWithName(@RequestParam(value="pn",defaultValue="1")Integer pn,String empName,Model model,
		   EmpQueryVo empQueryVo,HttpServletRequest request,HttpServletResponse response){
	 //引入PageHelper分页插件
	 		//在查询之前需要传入页码，每页大小
	 		//startPage后面紧跟的这个查询就是一个分页查询
	 		PageHelper.startPage(pn,10);
	 		List<Employee> emps=employeeService.getAllEmployeesWithEmpName(empQueryVo);
	 		System.out.println("----------"+emps);
	 		//使用PageInfo包装查询结果，只需要将PageInfo交给页面
	 		//封装详细的分页信息，包括有我们查询出来的数据,连续显示5页
	 		PageInfo<Employee> page = new PageInfo<Employee>(emps,5);
	 		System.out.println("-------------"+page);
	   
	 		return Msg.success().add("pageInfo", page);
   }
   
	
    //@RequestMapping("/emps")
	public String getEmployees(@RequestParam(value="pn",defaultValue="1")Integer pn,String empName,Model model,HttpServletRequest request,HttpServletResponse response){
		
		//引入PageHelper分页插件
		//在查询之前需要传入页码，每页大小
		//startPage后面紧跟的这个查询就是一个分页查询
		PageHelper.startPage(pn,10);
		List<Employee> emps=employeeService.getAllEmployees();
		//使用PageInfo包装查询结果，只需要将PageInfo交给页面
		//封装详细的分页信息，包括有我们查询出来的数据,连续显示5页
		PageInfo page = new PageInfo(emps,5);
		
		model.addAttribute("PageInfo",page);
		model.addAttribute("num",pn);
		
		
		return "employeeList";
	}
	
}
