package com.atguigu.crud.test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.atguigu.crud.bean.Department;
import com.atguigu.crud.bean.EmpQueryVo;
import com.atguigu.crud.bean.Employee;
import com.atguigu.crud.bean.EmployeeExample;
import com.atguigu.crud.dao.DepartmentMapper;
import com.atguigu.crud.dao.EmployeeMapper;

/**
 * 测试dao层
 * 类名称：MapperTest  
 * 类描述：spring项目推荐使用spring单元测试
 * 创建人：邱南亚 
 * 修改人：邱南亚 
 * 修改时间：2018-11-25 下午10:59:23 
 * 修改备注： 
 * ContextConfiguration:指定spring配置文件的位置
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:spring/applicationContext.xml"})
public class MapperTest {
    @Autowired
    DepartmentMapper departmentMapper;
    
    @Autowired
    EmployeeMapper employeeMapper;
    
    @Autowired
    SqlSession sqlSession;
	 
	//测试DepartmentMapper
	@Test
	public void testCRUD(){
		//原生测试
		/*//1.创建spring IOC容器
		ApplicationContext ioc=new ClassPathXmlApplicationContext("spring/applicationContext.xml");
		//2.从容器中获取mapper
		ioc.getBean(DepartmentMapper.class);*/
		System.out.println("获取接口属性成功"+departmentMapper);
		
		//1.插入部门
		/*Department department = new Department();
		department.setDeptName("开发部");
		department.setDeptName("测试部");*/
	departmentMapper.insertSelective(new Department(null,"开发部"));
	departmentMapper.insertSelective(new Department(null,"测试部"));
		
		
	}
	
	
	@Test
	public void insertEmployees(){
		        //1.生成员工数据
				//employeeMapper.insertSelective(new Employee(null, "Jerry","M", "158644@qq.com",1));
				//2.批量插入员工，使用sqlSession,在applicationContext.xml中先配置在使用
				EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
				for (int i = 0; i < 500; i++) {
					String uid = UUID.randomUUID().toString().substring(0, 5)+i;
					mapper.insertSelective(new Employee(null, uid, "M", uid+"@atguigu.com", 1));
					
				}
				System.out.println("批量插入完成啦^_^");
		
	}
	
	@Test
	public void deleteEmployee(){
		//根据id删除员工
		int  i= employeeMapper.deleteByPrimaryKey(505);
		System.out.println("删除数据成功"+i);
	}
	
	@Test
	public void deleteEmployeess(){
		//批量删除员工信息
		List<Integer> ids=new ArrayList<Integer>();
		
		ids.add(509);
		ids.add(510);
		ids.add(511);
		
		int result=employeeMapper.deleteByPrimaryKeyWithIds(ids);
		System.out.println("批量删除数据的id集合是："+result);
		
	}
	
	
	@Test
	public void updateEmployee(){
		//更新员工信息
		Employee employee=new Employee();
		employee.setdId(513);
		employee.setEmpName("qiuqiu");
		employee.setGender("女");
		employee.setEmail("dohfoh@qq.com");
		
		int result = employeeMapper.updateByPrimaryKeySelective(employee);
		System.out.println(result);
		
	}
	
	@Test
	public void selectEmployeByEmpName(){
//		EmployeeExample example=new EmployeeExample();
//		com.atguigu.crud.bean.EmployeeExample.Criteria createCriteria = example.createCriteria();
//		String empName="411";
//		createCriteria.andEmpNameLike(empName);
		
		
		//List<Employee> byExampleWithDept = employeeMapper.selectByExampleWithDept(example);
		
		EmpQueryVo empQueryVo = new EmpQueryVo();
		//empQueryVo.setEmp_name();
	    List<Employee> byExampleWithDept = employeeMapper.selectByExampleWithDepts(empQueryVo);
		System.err.println("通过用户名模糊查询结果如下："+byExampleWithDept);
	}
	
}
